$(document).ready(function () {
    $("#boton1").click(function () { 
        $("#parrafo_1").toggle("slow");;
    });

    $("#boton2").click(function () { 
        $("#parrafo2").toggle("slow");;
    });

    $("#boton3").click(function () { 
        $("#parrafo3").toggle("slow");;
    });
});
